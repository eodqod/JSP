package kr.human.listener;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

/**
 * Application Lifecycle Listener implementation class MyListener1
 *
 */
@WebListener // 이 어노테이션이 자동으로 등록해준다.
public class MyListener1 implements ServletContextListener {

    /**
     * Default constructor. 
     */
    public MyListener1() {
    	System.out.println("MyListener1 생성자 호출");
    	
    }

	/**
     * @see ServletContextListener#contextDestroyed(ServletContextEvent)
     */
    public void contextDestroyed(ServletContextEvent sce)  { 
    	System.out.println("MyListener1 contextDestroyed() 호출 : 앱 어플리케이션이 종료되었다.");
    }

	/**
     * @see ServletContextListener#contextInitialized(ServletContextEvent)
     */
    public void contextInitialized(ServletContextEvent sce)  { 
    	System.out.println("MyListener1 contextInitialized() 호출 : 앱 어플리케이션이 시작되었다.");
    }
	
}
