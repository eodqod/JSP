package kr.human.category.vo;

import lombok.Data;

@Data
public class CategoryVO {
	private int idx;
	private int ref;
	private int seq;
	private int lev;
	private String item;
	private String del;
}
