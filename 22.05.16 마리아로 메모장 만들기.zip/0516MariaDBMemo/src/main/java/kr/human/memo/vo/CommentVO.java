package kr.human.memo.vo;

import java.util.Date;

import lombok.Data;

/*
 * vo패키지에 CommentVO를 만들자 -- 테이블과 1:1 대응되도록 만든다.
 */

@Data
public class CommentVO {
	private int idx;
	private String name;
	private String password;
	private String content;
	private Date   regDate;
	private String ip;
	// 저장/수정/삭제 구분하기 위한 필드
	private String mode;
}
