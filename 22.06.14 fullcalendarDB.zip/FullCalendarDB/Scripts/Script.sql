-- HTTP 포트 확인
select dbms_xdb.gethttpport as "HTTP-Port" from dual;
-- 계정정보 확인하기
select username,account_status,lock_date from dba_users;
-- 잠긴 HR계정을 풀어보자
alter user hr account unlock;
-- hr 계정 암호 변경
alter user hr identified by "123456";