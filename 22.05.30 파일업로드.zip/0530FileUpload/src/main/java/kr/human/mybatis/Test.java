package kr.human.mybatis;

import java.io.File;

public class Test {
	public static void main(String[] args) {
		System.out.println(File.separator);
		System.out.println(File.pathSeparator);
		System.out.println("C:\\Users\\oss71\\OneDrive\\바탕 화면\\휴먼 qr코드.png".lastIndexOf(File.separator));
		System.out.println("휴먼 qr코드.png".lastIndexOf(File.separator));
	}
}
