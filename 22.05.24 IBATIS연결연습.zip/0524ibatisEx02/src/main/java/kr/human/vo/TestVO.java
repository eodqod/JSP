package kr.human.vo;

import lombok.Data;

@Data
public class TestVO {
	private String today;
	private int result;
}
