package kr.human.mybatis.test;

import static org.junit.Assert.assertNotNull;

import java.util.HashMap;

import org.apache.ibatis.session.SqlSession;
import org.junit.Test;

import kr.human.mybatis.MybatisApp;

public class MybatisTest {
	
	@Test
	public void dbTest() {
		SqlSession sqlSession = MybatisApp.getSqlSessionFactory().openSession();
		assertNotNull(sqlSession);
		sqlSession.close();
	}

	@Test
	public void createTable() {
		SqlSession sqlSession = null;
		try{
			
			sqlSession = MybatisApp.getSqlSessionFactory().openSession(false);
			
			// sqlSession.update("test.runUpdateSQL", "drop table memo");
			
			// 테이블 생성
			String sql = "create table IF NOT EXISTS memo("
					+ "			idx bigint auto_increment,"
					+ "			name varchar(255) not null,"
					+ "			password varchar(255) not null,"
					+ "			memo text not null,"
					+ "			regDate timestamp default now(),"
					+ "			ip varchar(20) not null"
					+ "		)";
			sqlSession.update("test.runUpdateSQL", sql);
			
			// 데이터 가져오기
			HashMap<String, Integer> map = sqlSession.selectOne("test.selectQuery","select count(*) cnt from memo");
			System.out.println(map + " : " + map.get("CNT"));
			sqlSession.commit();
		}catch(Exception e){
			sqlSession.rollback();
			e.printStackTrace();
		}finally{
			sqlSession.close();
		}
	}
}
