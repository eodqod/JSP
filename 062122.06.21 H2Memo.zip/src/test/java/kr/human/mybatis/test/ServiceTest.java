package kr.human.mybatis.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.Date;
import java.util.List;

import org.junit.Test;

import kr.human.memo.service.MemoService;
import kr.human.memo.service.MemoServiceImpl;
import kr.human.memo.vo.MemoVO;

public class ServiceTest {
	
	@Test
	public void crud() {
			MemoService memoService = MemoServiceImpl.getInstance();
			// 저장 테스트
			MemoVO memoVO = new MemoVO(0, "주인장", "1234", "메모장입니다.", new Date(), "192.168.0.124");
			memoService.insert(memoVO);
			
			// 목록보기 테스트
			List<MemoVO> list = memoService.selectList();
			assertNotNull(list);
			
			for(MemoVO vo : list) {
				System.out.println(vo);
			}
			
			// 변경 테스트
			int idx = list.get(list.size()-1).getIdx();
			System.out.println("마지막 번호 : " + idx);
			memoVO.setIdx(idx);
			memoVO.setMemo("바뀐내용");
			memoService.update(memoVO);
			list = memoService.selectList();
			assertEquals("바뀐내용", list.get(list.size()-1).getMemo());
			
			// 삭제 테스트
			int count = list.size();
			memoService.delete(memoVO);
			list = memoService.selectList();
			assertEquals(count, list.size()+1);
			
			for(MemoVO vo : list) {
				System.out.println(vo);
			}
	}

}
