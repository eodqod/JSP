package kr.human.mybatis.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.util.Date;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.junit.Test;

import kr.human.memo.dao.MemoDAO;
import kr.human.memo.dao.MemoDAOImpl;
import kr.human.memo.vo.MemoVO;
import kr.human.mybatis.MybatisApp;

public class DaoTest {
	
	@Test
	public void crud() {
		SqlSession sqlSession = null;
		MemoDAO dao = null;
		try{
			sqlSession = MybatisApp.getSqlSessionFactory().openSession(false);
			dao = MemoDAOImpl.getInstance();
			
			MemoVO memoVO = new MemoVO(0, "주인장", "1234", "메모장입니다.", new Date(), "192.168.0.124");
			dao.insert(sqlSession, memoVO);

			List<MemoVO> list = dao.selectList(sqlSession);
			assertNotNull(list);
			int idx = list.get(list.size()-1).getIdx();
			assertEquals("주인장", dao.selectByIdx(sqlSession, idx).getName());
			
			for(MemoVO vo : list) {
				System.out.println(vo);
			}
			
			memoVO = dao.selectByIdx(sqlSession, idx);
			memoVO.setMemo("바뀐내용");
			dao.update(sqlSession, memoVO);
			assertEquals("바뀐내용", dao.selectByIdx(sqlSession, idx).getMemo());
			
			dao.delete(sqlSession, idx);
			memoVO = dao.selectByIdx(sqlSession, 0);
			assertNull(memoVO);
			
			sqlSession.commit();
		}catch(Exception e){
			sqlSession.rollback();
			e.printStackTrace();
		}finally{
			sqlSession.close();
		}
	}

}
