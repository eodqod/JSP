package kr.human.mybatis.test;

import static org.junit.Assert.assertNotNull;

import java.util.Date;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.junit.Test;

import kr.human.memo.dao.MemoDAO;
import kr.human.memo.dao.MemoDAOImpl;
import kr.human.memo.vo.MemoVO;
import kr.human.mybatis.MybatisApp;

public class DaoTest2 {
	
	@Test
	public void crud() {
		SqlSession sqlSession = null;
		MemoDAO dao = null;
		try{
			sqlSession = MybatisApp.getSqlSessionFactory().openSession(false);
			dao = MemoDAOImpl.getInstance();
			
			MemoVO memoVO = new MemoVO(0, "주인장", "1234", "메모장입니다.", new Date(), "192.168.0.124");
			dao.insert(sqlSession, memoVO);

			List<MemoVO> list = dao.selectList(sqlSession);
			assertNotNull(list);
			
			for(MemoVO vo : list) {
				System.out.println(vo);
			}

			sqlSession.commit();
		}catch(Exception e){
			sqlSession.rollback();
			e.printStackTrace();
		}finally{
			sqlSession.close();
		}
	}

}
