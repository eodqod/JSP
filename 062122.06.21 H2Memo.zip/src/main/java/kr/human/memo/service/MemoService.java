package kr.human.memo.service;

import java.util.List;
import kr.human.memo.vo.MemoVO;

public interface MemoService {
	// 목록보기
	List<MemoVO> selectList();
	// 저장하기
	void insert(MemoVO memoVO);
	// 수정하기
	void update(MemoVO memoVO);
	// 삭제하기
	void delete(MemoVO memoVO);
}
