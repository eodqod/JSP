package kr.human.memo.service;

import java.sql.SQLException;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import kr.human.memo.dao.MemoDAO;
import kr.human.memo.dao.MemoDAOImpl;
import kr.human.memo.vo.MemoVO;
import kr.human.mybatis.MybatisApp;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class MemoServiceImpl implements MemoService {
	private static MemoService instance = new MemoServiceImpl();
	private MemoServiceImpl() {}
	public static MemoService getInstance() {
		return instance;
	}
	@Override
	public List<MemoVO> selectList() {
		log.info("MemoServiceImpl selectList 호출");
		List<MemoVO> list = null;
		MemoDAO dao = null;
		SqlSession sqlSession = null;
		try {
			sqlSession = MybatisApp.getSqlSessionFactory().openSession(false);
			dao = MemoDAOImpl.getInstance();
			
			list = dao.selectList(sqlSession);
			
			sqlSession.commit();
		}catch (SQLException e) {
			if(sqlSession!=null) sqlSession.rollback();
			e.printStackTrace();
		} finally {
			if(sqlSession!=null) sqlSession.close();
		}
		log.info("MemoServiceImpl selectList 리턴 : " + list);
		return list;
	}
	@Override
	public void insert(MemoVO memoVO) {
		log.info("MemoServiceImpl insert 호출 : " + memoVO);
		MemoDAO dao = null;
		SqlSession sqlSession = null;
		try {
			sqlSession = MybatisApp.getSqlSessionFactory().openSession(false);
			dao = MemoDAOImpl.getInstance();
			if(memoVO!=null) {
				dao.insert(sqlSession, memoVO);
			}
			sqlSession.commit();
		}catch (SQLException e) {
			if(sqlSession!=null) sqlSession.rollback();
			e.printStackTrace();
		} finally {
			if(sqlSession!=null) sqlSession.close();
		}
	}
	@Override
	public void update(MemoVO memoVO) {
		log.info("MemoServiceImpl update 호출 : " + memoVO);
		MemoDAO dao = null;
		SqlSession sqlSession = null;
		try {
			sqlSession = MybatisApp.getSqlSessionFactory().openSession(false);
			dao = MemoDAOImpl.getInstance();
			if(memoVO!=null) {
				MemoVO dbVO = dao.selectByIdx(sqlSession, memoVO.getIdx()); 
				if(dbVO!=null && dbVO.getPassword().equals(memoVO.getPassword())) {
					dao.update(sqlSession, memoVO);
				}
			}
			sqlSession.commit();
		}catch (SQLException e) {
			if(sqlSession!=null) sqlSession.rollback();
			e.printStackTrace();
		} finally {
			if(sqlSession!=null) sqlSession.close();
		}
	}
	@Override
	public void delete(MemoVO memoVO) {
		log.info("MemoServiceImpl delete 호출 : " + memoVO);
		MemoDAO dao = null;
		SqlSession sqlSession = null;
		try {
			sqlSession = MybatisApp.getSqlSessionFactory().openSession(false);
			dao = MemoDAOImpl.getInstance();
			if(memoVO!=null) {
				MemoVO dbVO = dao.selectByIdx(sqlSession, memoVO.getIdx()); 
				if(dbVO!=null && dbVO.getPassword().equals(memoVO.getPassword())) {
					dao.delete(sqlSession, memoVO.getIdx());
				}
			}
			sqlSession.commit();
		}catch (SQLException e) {
			if(sqlSession!=null) sqlSession.rollback();
			e.printStackTrace();
		} finally {
			if(sqlSession!=null) sqlSession.close();
		}
	}
}
