package kr.human.memo.dao;

import java.sql.SQLException;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import kr.human.memo.vo.MemoVO;

public class MemoDAOImpl implements MemoDAO {
	private static MemoDAO instance = new MemoDAOImpl();
	private MemoDAOImpl() {}
	public static MemoDAO getInstance() {
		return instance;
	}
	@Override
	public List<MemoVO> selectList(SqlSession sqlSession)  throws SQLException{
		return sqlSession.selectList("memo.selectList");
	}
	@Override
	public MemoVO selectByIdx(SqlSession sqlSession, int idx) throws SQLException {
		return sqlSession.selectOne("memo.selectByIdx", idx);
	}
	@Override
	public void insert(SqlSession sqlSession, MemoVO memoVO)  throws SQLException{
		sqlSession.insert("memo.insert", memoVO);
	}
	@Override
	public void update(SqlSession sqlSession, MemoVO memoVO)  throws SQLException{
		sqlSession.update("memo.update", memoVO);
	}
	@Override
	public void delete(SqlSession sqlSession, int idx) throws SQLException {
		sqlSession.delete("memo.delete", idx);
	}
}
