package kr.human.memo.dao;

import java.sql.SQLException;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import kr.human.memo.vo.MemoVO;

public interface MemoDAO {
	List<MemoVO> selectList(SqlSession sqlSession) throws SQLException;
	MemoVO selectByIdx(SqlSession sqlSession, int idx) throws SQLException;
	void insert(SqlSession sqlSession, MemoVO memoVO) throws SQLException;
	void update(SqlSession sqlSession, MemoVO memoVO) throws SQLException;
	void delete(SqlSession sqlSession, int idx) throws SQLException;
}
